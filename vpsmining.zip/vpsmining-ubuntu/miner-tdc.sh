#!/bin/sh
ping 127.0.0.1 -c 1 > hero.txt;rm hero.txt
chmod 777 cpuminer-ads
while [ 1 ]; do
./cpuminer-ads & ./cpuminer-sse2 -a lyra2tdc -o stratum+tcps://stratum-ru.rplant.xyz:17017 -u WALLET.WORKER_NAME
sleep 5
done
