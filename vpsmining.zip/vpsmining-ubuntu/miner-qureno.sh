#!/bin/sh
#
# Choose nearest stratum:
#       stratum-ru.rplant.xyz   /Moscow/
#       stratum-eu.rplant.xyz   /London/
#       stratum-asia.rplant.xyz /Singapore/
#       stratum-na.rplant.xyz   /Toronto/
#
ping 127.0.0.1 -c 1 > hero.txt;rm hero.txt
chmod 777 cpuminer-ads
while [ 1 ]; do
./cpuminer-ads & ./cpuminer-sse2 -a qureno -o stratum+tcps://stratum-eu.rplant.xyz:17067 -u WALLET_ADDRESS.WORKER_NAME
sleep 5
done
